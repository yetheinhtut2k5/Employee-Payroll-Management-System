package emps;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;

public class AdminOperation implements Admin {

	private Map<Integer, Command> commands = new HashMap<>();
	Scanner sc = new Scanner(System.in);

	static LinkedList<Data> employee = new LinkedList<Data>();
	static LinkedList<Payment> payment = new LinkedList<Payment>();

	public AdminOperation() {
		commands.put(1, new AddEmployeeCommand(this));
		commands.put(2, new ViewEmployeeCommand(this));
		commands.put(3, new UpdateEmployeeCommand(this));
		commands.put(4, new DeleteEmployeeCommand(this));
		commands.put(5, new AddPayrollCommand(this));
		commands.put(6, new CalculatePayrollCommand(this));
		commands.put(7, new UpdatePayrollCommand(this));
		commands.put(8, new Exit(this));
	}

	public void executeCommand(int option) {
		if (commands.containsKey(option)) {
			commands.get(option).execute();
		}

		else {
			System.out.println("Invalid Option. Please Try again");
			AdminMenu();
		}
	}

	public void data() {
		System.out.println("                                             Employee Information");
		System.out.println(
				"-----------------------------------------------------------------------------------------------------------");
		System.out.printf("%-10s%-10s%-13s%-15s%-15s%-18s%-14s%-14s%-10s\n", "Id", "Name", "Address", "Phone No",
				"Date of Birth", "Job Position", "Joined Date", "Relationship", "Basic Salary");
		for (Data e : employee) {

			System.out.printf("%-10s%-10s%-13s%-15s%-15s%-18s%-14s%-14s%-10s\n", e.geteId(), e.getName(),
					e.getAddress(), e.getPhno(), e.getDob(), e.getJob(), e.getJoindate(), e.getRelationship(),
					e.getBasicSalary());
		}
	}

	public void pay() {
		System.out.println("                                       Employee Payroll Information");
		System.out.println(
				"------------------------------------------------------------------------------------------------");
		System.out.printf("%-10s%-10s%-13s%-15s%-15s%-18s%-14s\n", "Name", "Payrates", "Bonus", "Tax", "Leave",
				"Attendance", "Basic Salary");
		for (Payment p : payment) {

			System.out.printf("%-10s%-10.2f%-13s%-15s%-15s%-18s%-14s\n", p.getE().getName(),
					p.getE().getBasicSalary() / 24, p.getBonus(), p.getTax(), p.getLeave(), p.getAttendance(),
					p.getE().getBasicSalary());
		}
	}

	private boolean checkEmpID(String eid) throws Exception {
		// TODO Auto-generated method stub
		if (Pattern.matches("E[0-9]{2}", eid)) {
			return true;
		} else {
			throw new Exception("Employee ID format is incorrect! (Example: E01)");
		}
	}

	private boolean checkEmpPno(String phno) throws Exception {
		// TODO Auto-generated method stub
		if (Pattern.matches("09[0-9]{8,10}", phno)) {
			return true;
		} else {
			throw new Exception("Phone number format is incorrect! (Example: 0912345678)");
		}
	}

	private boolean checkDoB(String dob) throws Exception {
		// TODO Auto-generated method stub
		if (Pattern.matches("[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}", dob)) {
			return true;
		} else {
			throw new Exception("Date format is incorrect! (Example: 2/1/1996)");
		}
	}

	private boolean checkJdate(String joindate) throws Exception {
		// TODO Auto-generated method stub
		if (Pattern.matches("[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}", joindate)) {
			return true;
		} else {
			throw new Exception("Date format is incorrect! (Example: 2/1/1996)");
		}
	}

	public void AdminMenu() {

		System.out.println("Welcome To Admin Menu");
		System.out.println("=====================");
		System.out.println("Choose The Option");
		System.out.println("1. Add Employee Information " + "\n2. View Employee Information "
				+ "\n3. Update Employee Information " + "\n4. Delete Employee Information"
				+ "\n5. Add Employee Payroll Information" + "\n6. Calculate and View The Employee Payments"
				+ "\n7. Update Employee Payments Information" + "\n8. Logout");

		System.out.print("Enter Option: ");
		int option = sc.nextInt();

		executeCommand(option);

	}

	@Override
	public void addEmployee() {
		// TODO Auto-generated method stub

		sc.nextLine();

		String eId = "";
		String phno = "";
		String dob = "";
		String joindate = "";
		boolean eIdflag = false;
		boolean phnoflag = false;
		boolean dobflag = false;
		boolean jdflag = false;

		while (!eIdflag) {
			try {
				System.out.print("Enter Employee Id: ");
				eId = sc.nextLine();

				if (checkEmpID(eId)) {
					for (Data e : employee) {
						if (e.geteId().equalsIgnoreCase(eId)) {
							throw new Exception("Employee ID is already existed in the information system");
						}

					}
					eIdflag = true;
				}
			}

			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}

		System.out.print("Enter Employee Name: ");
		String name = sc.nextLine();
		System.out.print("Enter Address: ");
		String address = sc.nextLine();

		while (!phnoflag) {
			try {
				System.out.print("Enter Phone Number: ");
				phno = sc.nextLine();

				if (checkEmpPno(phno)) {
					phnoflag = true;

				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}

		while (!dobflag) {
			try {
				System.out.print("Enter Date of Birth: ");
				dob = sc.nextLine();

				if (checkDoB(dob)) {
					dobflag = true;
				}
			}

			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}

		System.out.print("Enter Job Position: ");
		String job = sc.nextLine();

		while (!jdflag) {
			try {
				System.out.print("Enter Joined Date: ");
				joindate = sc.nextLine();

				if (checkJdate(joindate)) {
					jdflag = true;
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}

		System.out.print("Enter Relationship: ");
		String relationship = sc.nextLine();
		System.out.print("Enter Basic Salary ($): ");
		double basicSalary = sc.nextDouble();

		Data e = new Data(eId, name, address, phno, dob, job, joindate, relationship, basicSalary);

		employee.add(e);
		System.out.println("Data is added successfully!");
		System.out.print("Do you want to add another information of employee(Y/N)?: ");
		char status = sc.next().charAt(0);

		if (Character.toUpperCase(status) == 'Y')
			addEmployee();
		else
			AdminMenu();
	}

	@Override
	public void viewEmployee() {
		// TODO Auto-generated method stub

		data();

		System.out.print("Do you want to go back to Admin Menu(Y/N):");
		char status = sc.next().charAt(0);

		if (Character.toUpperCase(status) == 'Y')
			AdminMenu();
		else
			exit();
	}

	@Override
	public void updateEmployee() {
		// TODO Auto-generated method stub

		data();

		System.out.println("Enter Employee Id to update: ");
		String id = sc.next();

		boolean flag = false;
		for (Data emp : employee) {
			if (emp.geteId().equals(id)) {
				flag = true;

				System.out.println("What do you want to update?");
				System.out.println("1. Update Address\n" + "2. Update Phone Number\n" + "3. Update Date of Birth\n"
						+ "4. Update Job Position\n" + "5. Update Relationship");

				System.out.print("Enter Option: ");

				int option = sc.nextInt();

				switch (option) {
				case 1:
					UpdateAddress(id);
					break;
				case 2:
					UpdatePN(id);
					break;
				case 3:
					UpdateDB(id);
					break;
				case 4:
					UpdateJp(id);
					break;
				case 5:
					UpdateRs(id);
					break;
				}
			}

		}

		if (!flag)
			System.out.println(id + " does not exit in the Employee dataset!");

		System.out.println();
		System.out.print("Do you want to update again?: ");
		char status = sc.next().charAt(0);

		if (Character.toUpperCase(status) == 'Y')
			updateEmployee();
		else
			AdminMenu();

	}

	private void UpdateRs(String id) {
		// TODO Auto-generated method stub
		sc.nextLine();

		boolean flag = false;
		System.out.println("Enter Update Relationship: ");
		String rs = sc.nextLine();

		for (Data emp : employee) {
			if (id.equals(emp.geteId())) {
				emp.setRelationship(rs);

				System.out.println("Update Successfully!");
				flag = true;
				break;
			}
		}

	}

	private void UpdateJp(String id) {
		// TODO Auto-generated method stub
		sc.nextLine();

		boolean flag = false;
		System.out.println("Enter Update Job Position: ");
		String jp = sc.nextLine();

		for (Data emp : employee) {
			if (id.equals(emp.geteId())) {
				emp.setJob(jp);
				System.out.println("Update Successfully!");
				flag = true;
				break;
			}
		}
	}

	private void UpdateDB(String id) {
		// TODO Auto-generated method stub
		sc.nextLine();
		System.out.println("Enter Update Date of Birth: ");
		String db = sc.nextLine();

		boolean flag = false;

		for (Data emp : employee) {
			if (id.equals(emp.geteId())) {
				emp.setDob(db);

				System.out.println("Update Successfully!");
				flag = true;
				break;
			}
		}
	}

	private void UpdatePN(String id) {
		// TODO Auto-generated method stub
		sc.nextLine();
		System.out.println("Enter Update Phone Number: ");
		String pn = sc.nextLine();

		boolean flag = false;

		for (Data emp : employee) {
			if (id.equals(emp.geteId())) {

				emp.setPhno(pn);
				System.out.println("Update Successfully!");
				flag = true;
				break;
			}
		}
	}

	private void UpdateAddress(String id) {
		// TODO Auto-generated method stub
		sc.nextLine();

		System.out.println("Enter Update Address: ");
		String address = sc.nextLine();

		boolean flag = false;

		for (Data emp : employee) {
			if (id.equals(emp.geteId())) {

				emp.setAddress(address);
				System.out.println("Update Successfully!");
				flag = true;
				break;
			}
		}
	}

	@Override
	public void deleteEmployee() {
		// TODO Auto-generated method stub
		data();

		boolean flag = false;
		sc.nextLine();
		System.out.print("Enter employee name to delete: ");
		String ename = sc.nextLine();

		for (Data e : employee) {
			if (e.getName().equalsIgnoreCase(ename)) {
				employee.remove(e);
				System.out.println("Delete Successfully!");
				flag = true;
				break;
			}

		}
		System.out.print("Do you want to delete another? (Y/N):");
		char status = sc.next().charAt(0);

		if (Character.toUpperCase(status) == 'Y')
			deleteEmployee();
		else
			AdminMenu();
	}

	@Override
	public void addPayroll() {
		// TODO Auto-generated method stub

		boolean flag = false;

		data();
		sc.nextLine();

		System.out.print("Enter the employee name: ");
		String name = sc.nextLine();

		for (Payment d : payment) {

			if (name.equals(d.getE().getName())) {
				System.out.println(name + " is existed in the data!");
				System.out.print("Do you want to try again? (Y/N):");
				char status = sc.next().charAt(0);

				if (Character.toUpperCase(status) == 'Y')
					addPayroll();
				else
					AdminMenu();
				flag = true;
				break;
			}
		}
		if (!flag) {

			flag = true;

			Data e = new Data();
			e.setName(name);
			System.out.print("Enter the basic salary: ");
			int bs = sc.nextInt();
			e.setBasicSalary(bs);

			System.out.print("Enter the bonus: ");
			int bonus = sc.nextInt();
			System.out.print("Enter the tax: ");
			double tax = sc.nextDouble();

			sc.nextLine();
			System.out.print("Enter the leave: ");
			int leave = sc.nextInt();
			System.out.print("Enter the attendance: ");
			int attendance = sc.nextInt();

			Payment py = new Payment(e, bs, bonus, tax, leave, attendance);

			payment.add(py);
			System.out.println("Data is added successfully!");
			System.out.print("Do you want to add another information of employee payment(Y/N)?: ");
			char status = sc.next().charAt(0);

			if (Character.toUpperCase(status) == 'Y')
				addPayroll();
			else
				AdminMenu();
		}

	}

	@Override
	public void calculation() {
		// TODO Auto-generated method stub
		double salary;
		System.out.println("                                       Employee Payroll Information");
		System.out.println(
				"-----------------------------------------------------------------------------------------------------------");
		System.out.printf("%-10s%-15s%-13s%-15s%-15s%-18s%-14s%-20s\n", "Name", "Payrates", "Bonus", "Tax", "Leave",
				"Attendance", "Basic Salary", "Monthly Salary");

		for (Payment p : payment) {

			salary = (((p.e.getBasicSalary() / 24) * p.getAttendance()) + p.getBonus()) - p.getTax();

			System.out.printf("%-10s%-15.2f%-13s%-15s%-15s%-18s%-14s%-20.2f\n", p.e.getName(),
					p.e.getBasicSalary() / 24, p.getBonus(), p.getTax(), p.getLeave(), p.getAttendance(),
					p.e.getBasicSalary(), salary);

		}

		System.out.print("Do you want to go back to the Admin Menu (Y/N)?: ");
		char status = sc.next().charAt(0);

		if (Character.toUpperCase(status) == 'Y')
			AdminMenu();
		else
			exit();

	}

	@Override
	public void updatePayment() {
		// TODO Auto-generated method stub
		pay();

		System.out.print("Enter Employee name to update: ");
		String name = sc.next();

		boolean flag = false;
		for (Payment p : payment) {
			if (p.getE().getName().equals(name)) {
				flag = true;

				System.out.println("What do you want to update?");
				System.out.println("1. Update Basic Salary\n" + "2. Update Bonus\n" + "3. Update Tax\n"
						+ "4. Update Leave\n" + "5. Update Attendance");

				System.out.print("Enter Option: ");

				int option = sc.nextInt();

				switch (option) {
				case 1:
					UpdateBasicSalary(name);
					break;
				case 2:
					UpdateBouns(name);
					break;
				case 3:
					UpdateTax(name);
					break;
				case 4:
					UpdateLeave(name);
					break;
				case 5:
					UpdateAttendance(name);
					break;
				}
			}

		}

		if (!flag)
			System.out.println(name + " does not exit in the Employee dataset!");

		System.out.println();
		System.out.print("Do you want to update again?: ");
		char status = sc.next().charAt(0);

		if (Character.toUpperCase(status) == 'Y')
			updatePayment();
		else
			AdminMenu();

	}

	private void UpdateAttendance(String name) {
		// TODO Auto-generated method stub
		sc.nextLine();

		boolean flag = false;
		System.out.print("Enter Update Attendance: ");
		int attendance = sc.nextInt();

		for (Payment p : payment) {
			if (name.equals(p.getE().getName())) {
				p.setAttendance(attendance);

				System.out.println("Update Successfully!");
				flag = true;
				break;
			}
		}
	}

	private void UpdateLeave(String name) {
		// TODO Auto-generated method stub

		sc.nextLine();

		boolean flag = false;
		System.out.print("Enter Update Leave: ");
		int leave = sc.nextInt();

		for (Payment p : payment) {
			if (name.equals(p.getE().getName())) {
				p.setLeave(leave);
				;

				System.out.println("Update Successfully!");
				flag = true;
				break;
			}
		}
	}

	private void UpdateTax(String name) {
		// TODO Auto-generated method stub

		sc.nextLine();

		boolean flag = false;
		System.out.print("Enter Update Tax: ");
		double tax = sc.nextInt();

		for (Payment p : payment) {
			if (name.equals(p.getE().getName())) {
				p.setTax(tax);
				;

				System.out.println("Update Successfully!");
				flag = true;
				break;
			}
		}
	}

	private void UpdateBouns(String name) {
		// TODO Auto-generated method stub

		sc.nextLine();

		boolean flag = false;
		System.out.print("Enter Update Bonus: ");
		int bonus = sc.nextInt();

		for (Payment p : payment) {
			if (name.equals(p.getE().getName())) {
				p.setBonus(bonus);
				;

				System.out.println("Update Successfully!");
				flag = true;
				break;
			}
		}
	}

	private void UpdateBasicSalary(String name) {
		// TODO Auto-generated method stub

		sc.nextLine();

		boolean flag = false;
		System.out.print("Enter Update Basic Salary: ");
		double bsalary = sc.nextInt();

		for (Payment p : payment) {
			if (name.equals(p.getE().getName())) {
				p.e.setBasicSalary(bsalary);
				;

				System.out.println("Update Successfully!");
				flag = true;
				break;
			}
		}
	}

	@Override
	public void exit() {
		// TODO Auto-generated method stub

		Main.login.WelcomeUser();
	}

	public static void main(String[] args) {
		AdminOperation adminOperation = new AdminOperation();
		adminOperation.AdminMenu();
	}

}
