package emps;

import java.util.Scanner;

public class Main {

	static Login login = new Login();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		login.WelcomeUser();
	}

}
