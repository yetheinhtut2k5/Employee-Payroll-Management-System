package emps;


import java.util.LinkedList;
import java.util.Scanner;

public class EmployeeOperation implements Employee {

	Scanner sc = new Scanner(System.in);
	
	private static EmployeeOperation instance;
	
	private EmployeeOperation()
	{
		
	}
	
	public static EmployeeOperation getInstance() {
	    if (instance == null) {
	      instance = new EmployeeOperation();
	    }
	    return instance;
	  }	
	

	@Override
	public void UserMenu() {
		// TODO Auto-generated method stub
		 
		System.out.println("Welcome To Employee Menu");
		System.out.println("========================");
		System.out.println("Choose Option "
				+ "\n1. View Employee Information By Name"
				+ "\n2. View Employee Payments Information By Name"
				+ "\n3. Logout");
		
		System.out.print("Enter Option: ");
		int option = sc.nextInt();
		switch (option)
		{
		case 1: 
			viewInformation();
			break;
		case 2:
			viewPayments();
			break;
		case 3:
			exit();
			break;
			
		default: {
			System.out.println("Invalid Input. Please try again!");
			UserMenu();
		}
		}
	}

	@Override
	public void viewInformation() {
		// TODO Auto-generated method stub
		
		boolean a = false;
		sc.nextLine();
		System.out.print("Enter Employee Name: ");
		String ename = sc.nextLine();
		
		for (Data e: AdminOperation.employee   )
		{
			if (e.getName().equalsIgnoreCase(ename))
			{
				System.out.println("                                             Employee Information");
				System.out.println(
						"-----------------------------------------------------------------------------------------------------------------------------");
				System.out.printf("%-10s%-10s%-13s%-15s%-15s%-18s%-14s%-14s%-16s\n", "Id", "Name", "Address", "Phone No",
						"Date of Birth", "Job Position", "Joined Date", "Relationship", "Basic Salary");
				

					System.out.printf("%-10s%-10s%-13s%-15s%-15s%-18s%-14s%-14s%-16s\n", e.geteId(), e.getName(), e.getAddress(),
							e.getPhno(), e.getDob(), e.getJob(), e.getJoindate(), e.getRelationship(), e.getBasicSalary());
					a=true;
					break;
				
			}
		}
		
		if(!a)
			System.out.println(ename +" does not exit in the information of employee!");
		
		System.out.print("Do you want to view again?: ");
		char status = sc.next().charAt(0);

		if (Character.toUpperCase(status) == 'Y')
			viewInformation();
		else
			UserMenu();
	}

	@Override
	public void viewPayments() {
		// TODO Auto-generated method stub
		
		boolean a = false;
		sc.nextLine();
		System.out.print("Enter Employee Name: ");
		String ename = sc.nextLine();
		
		for (Payment e: AdminOperation.payment   )
		{
			if (e.getE().getName().equalsIgnoreCase(ename))
			{
				System.out.println("                                      Employee Payroll Information");
				System.out.println(
						"-----------------------------------------------------------------------------------------------------------");
				System.out.printf("%-10s%-15s%-13s%-15s%-15s%-18s%-14s\n", "Name", "Payrates", "Bonus", "Tax", "Leave",
						"Attendance", "Basic Salary");
				

					System.out.printf("%-10s%-15.2f%-13s%-15s%-15s%-18s%-14s\n", e.getE().getName(), e.getE().getBasicSalary()/24,
							e.getBonus(), e.getTax(), e.getLeave(), e.getAttendance(), e.getE().getBasicSalary());
					a=true;
					break;
				
			}
		}
		
		if(!a)
			System.out.println(ename +" does not exit in the information of employee!");
		
		System.out.print("Do you want to view again?: ");
		char status = sc.next().charAt(0);

		if (Character.toUpperCase(status) == 'Y')
			viewInformation();
		else
			UserMenu();
		
	}

	@Override
	public void exit() {
		// TODO Auto-generated method stub
		
		Main.login.WelcomeUser();
	}

}
