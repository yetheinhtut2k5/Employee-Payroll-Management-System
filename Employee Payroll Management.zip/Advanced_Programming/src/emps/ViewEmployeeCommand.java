package emps;

public class ViewEmployeeCommand implements Command{

private AdminOperation adminOperation;
	
	public ViewEmployeeCommand (AdminOperation adminOperation)
	{
		this.adminOperation = adminOperation;
	}
	public void execute() {
		// TODO Auto-generated method stub

		adminOperation.viewEmployee();
	}

}
