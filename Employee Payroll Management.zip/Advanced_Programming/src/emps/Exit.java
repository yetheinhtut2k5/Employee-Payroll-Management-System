package emps;

public class Exit implements Command {

private AdminOperation adminOperation;
	
	public Exit (AdminOperation adminOperation)
	{
		this.adminOperation = adminOperation;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub

		adminOperation.exit();;
	}

}
