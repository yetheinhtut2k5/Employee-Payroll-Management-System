package emps;

public class UpdatePayrollCommand implements Command {

private AdminOperation adminOperation;
	
	public UpdatePayrollCommand (AdminOperation adminOperation)
	{
		this.adminOperation = adminOperation;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub

		adminOperation.updatePayment();
	}

}
