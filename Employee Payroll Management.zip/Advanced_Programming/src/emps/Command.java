package emps;

public interface Command {

	void execute();
}
