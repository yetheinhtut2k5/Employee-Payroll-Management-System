package emps;

public class AddPayrollCommand implements Command {

	private AdminOperation adminOperation;
	
	public AddPayrollCommand (AdminOperation adminOperation)
	{
		this.adminOperation = adminOperation;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub

		adminOperation.addPayroll();
	}

}
