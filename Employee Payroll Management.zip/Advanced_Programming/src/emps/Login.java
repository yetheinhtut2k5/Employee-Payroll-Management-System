package emps;

import java.util.Scanner;

public class Login {

	Scanner sc = new Scanner(System.in);
	
	AdminOperation admin;
	
	EmployeeOperation employee = EmployeeOperation.getInstance();
	
	public Login() {
		admin = new AdminOperation();
		
		
		Data e1 = new Data("E01", "Neon", "Yangon", "0912345678", "1/1/2000", "Developer", "5/6/2019", "Single", 6000);
		Data e2 = new Data("E02", "Jett", "Insein", "0923456789", "2/5/1996", "Senior Developer", "7/8/2020", "Married", 8000);
		Data e3 = new Data("E03", "Rena", "Taunggyi", "0934567891", "3/1/1998", "Analysis", "23/9/201", "Single", 7000);
		Data e4 = new Data("E04", "Sage", "Manadalay", "0945678912", "1/1/1995", "Manager", "14/5/2016", "Married", 10000);
		Data e5 = new Data("E05", "Omen", "Bago", "0956789123", "1/1/1997", "Researcher", "28/10/2017", "Single", 9000);
		
		admin.employee.add(e1);
		admin.employee.add(e2);
		admin.employee.add(e3);
		admin.employee.add(e4);
		admin.employee.add(e5);
		
		Payment p1 = new Payment(e1, 250, 300, 100, 3, 28);
		Payment p2 = new Payment(e2, 333, 300, 100, 3, 28);
		Payment p3 = new Payment(e3, 291, 300, 100, 3, 28);
		Payment p4 = new Payment(e4, 416, 300, 100, 3, 28);
		Payment p5 = new Payment(e5, 216, 300, 100, 3, 28);
		
		admin.payment.add(p1);
		admin.payment.add(p2);
		admin.payment.add(p3);
		admin.payment.add(p4);
		admin.payment.add(p5);

		
	}

	public void WelcomeUser() {
		System.out.println("Welcome to the Employee PayRoll Management System");
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("Choose the User Option \n1. Admin \n2. Employee User \n3. Exit");

		System.out.print("Enter User Option: ");
		int user = sc.nextInt();

		switch (user) {
		case 1:
			Admin();
			break;
		case 2:
			Employee();
			break;
		case 3:
			Exit();
			break;
		default: {
			System.out.println("Invalid Input! Please Try Again!");
			WelcomeUser();

		}
		}
	}

	private void Admin() {
		// TODO Auto-generated method stub
		
		sc.nextLine();

		System.out.print("Enter Admin Username: ");
		String username = sc.nextLine();

		System.out.print("Enter Admin Password: ");
		String pass = sc.next();

		if (username.equals("Admin") && pass.equals("admin123!@#")) {
			System.out.println("Login Successfully!");
			System.out.println();
			admin.AdminMenu();
			
			

		} else {
			System.out.println("Invalid username and password, please try again!");
			Admin();
		}
	}

	private void Employee() {
		// TODO Auto-generated method stub
		sc.nextLine();
		System.out.print("Enter Employee Username: ");
		String username = sc.nextLine();

		System.out.print("Enter Employee Password: ");
		String pass = sc.next();

		if (username.equals("Employee") && pass.equals("employee123!@#")) {
			System.out.println("Login Successfully!");
			employee.UserMenu();

		} else {
			System.out.println("Invalid username and password, please try again!");
			Employee();
		}
	}

	private void Exit() {
		// TODO Auto-generated method stub

		System.out.println("Thank You");
		System.exit(0);
	}

}
