package emps;

public class Payment {

    Data e;
	private int payrates;
	private int bonus;
	private double tax;
	private int leave;
	private int attendance;
	private double sal;
	
	public Payment(Data e, int payrates, int bonus, double tax, int leave, int attendance, double sal) {
		this.e = e;
		this.payrates = payrates;
		this.bonus = bonus;
		this.tax = tax;
		this.leave = leave;
		this.attendance = attendance;
		this.sal = sal;
	}
	

	public Payment(Data e, int payrates, int bonus, double tax, int leave, int attendance) {
		this.e = e;
		this.payrates = payrates;
		this.bonus = bonus;
		this.tax = tax;
		this.leave = leave;
		this.attendance = attendance;
	}    


	public Data getE() {
		return e;
	}
	public void setE(Data e) {
		this.e = e;
	}
	public int getPayrates() {
		return payrates;
	}
	public void setPayrates(int payrates) {
		this.payrates = payrates;
	}
	public int getBonus() {
		return bonus;
	}
	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
	public double getTax() {
		return tax;
	}
	public void setTax(double tax) {
		this.tax = tax;
	}
	public int getLeave() {
		return leave;
	}
	public void setLeave(int leave) {
		this.leave = leave;
	}
	public int getAttendance() {
		return attendance;
	}
	public void setAttendance(int attendance) {
		this.attendance = attendance;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	
}
