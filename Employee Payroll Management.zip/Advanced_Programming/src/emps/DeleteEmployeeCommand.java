package emps;

public class DeleteEmployeeCommand implements Command {

private AdminOperation adminOperation;
	
	public DeleteEmployeeCommand (AdminOperation adminOperation)
	{
		this.adminOperation = adminOperation;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub

		adminOperation.deleteEmployee();
	}

}
