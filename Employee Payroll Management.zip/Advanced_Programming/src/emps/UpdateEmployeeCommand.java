package emps;

public class UpdateEmployeeCommand implements Command {

private AdminOperation adminOperation;
	
	public UpdateEmployeeCommand (AdminOperation adminOperation)
	{
		this.adminOperation = adminOperation;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub

		adminOperation.updateEmployee();
	}

}
