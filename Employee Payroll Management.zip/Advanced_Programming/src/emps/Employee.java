package emps;

public interface Employee {

	public void UserMenu();
	
	public void viewInformation();
	
	public void viewPayments();
	
	public void exit();
	
	
	
	
}
