package emps;

public interface Admin {

	public void AdminMenu();
	
	public void addEmployee();
	
	public void viewEmployee();
	
	public void updateEmployee();
	
	public void deleteEmployee();
	
	public void addPayroll();
	
	public void calculation();
	
	public void updatePayment();
	
	public void exit();
	
	
	
	
}
